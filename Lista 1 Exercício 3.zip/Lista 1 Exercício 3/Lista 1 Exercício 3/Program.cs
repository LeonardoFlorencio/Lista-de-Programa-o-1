﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista_1_Exercício_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double lado;
            double resultado;

            Console.WriteLine("Lista 1 - Exercício 3");
            Console.Write("");

            Console.Write("Informe o valor da diagonal: ");
            diagonal = double.Parse(Console.ReadLine());

            lado = diagonal / Math.Sqrt(2);
            resultado = Math.Pow(lado, 2);

            Console.WriteLine("resultado: {0}", resultado);
        }
    }
}
