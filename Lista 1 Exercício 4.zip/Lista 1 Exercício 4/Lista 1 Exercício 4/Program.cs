﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista_1_Exercício_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura;
            double Área;

            Console.WriteLine("Lista 1 - Exercício 4");
            Console.WriteLine("");

            Console.Write("Informe o valor da Base do triângulo: ");
            base1 = double.Parse(Console.ReadLine());

            Console.Write("Informe o valor da Altura do triângulo: ");
            altura = double.Parse(Console.ReadLine());

            Área = (base1 * altura) / 2;
            Console.WriteLine("Área: {0}", Área);

        }
    }
}
