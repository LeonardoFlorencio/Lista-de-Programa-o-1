﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista_1_Exercício_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double aresta;
            double resultado;

            Console.WriteLine("Lista 1 - Exercício 2 ");
            Console.WriteLine("");

            Console.Write("Informe o valor da aresta: ");
            aresta = double.Parse(Console.ReadLine());

            resultado = Math.Pow(aresta, 2);

            Console.WriteLine("Resultado: {0}", resultado);
            Console.Read();
        }
    }
}
